#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <chrono>
#include <sstream>
#include <vector>
#include <memory>
using namespace std;

// DES������
const int IP[] = {
    58, 50, 42, 34, 26, 18, 10, 2,
    60, 52, 44, 36, 28, 20, 12, 4,
    62, 54, 46, 38, 30, 22, 14, 6,
    64, 56, 48, 40, 32, 24, 16, 8,
    57, 49, 41, 33, 25, 17, 9, 1,
    59, 51, 43, 35, 27, 19, 11, 3,
    61, 53, 45, 37, 29, 21, 13, 5,
    63, 55, 47, 39, 31, 23, 15, 7
};

const int IP_INV[] = {
    40, 8, 48, 16, 56, 24, 64, 32,
    39, 7, 47, 15, 55, 23, 63, 31,
    38, 6, 46, 14, 54, 22, 62, 30,
    37, 5, 45, 13, 53, 21, 61, 29,
    36, 4, 44, 12, 52, 20, 60, 28,
    35, 3, 43, 11, 51, 19, 59, 27,
    34, 2, 42, 10, 50, 18, 58, 26,
    33, 1, 41, 9, 49, 17, 57, 25
};

const int PC1[] = {
    57, 49, 41, 33, 25, 17, 9, 1,
    58, 50, 42, 34, 26, 18, 10, 2,
    59, 51, 43, 35, 27, 19, 11, 3,
    60, 52, 44, 36, 63, 55, 47, 39,
    31, 23, 15, 7, 62, 54, 46, 38,
    30, 22, 14, 6, 61, 53, 45, 37,
    29, 21, 13, 5, 28, 20, 12, 4
};

const int PC2[] = {
    14, 17, 11, 24, 1, 5, 3, 28,
    15, 6, 21, 10, 23, 19, 12, 4,
    26, 8, 16, 7, 27, 20, 13, 2,
    41, 52, 31, 37, 47, 55, 30, 40,
    51, 45, 33, 48, 44, 49, 39, 56,
    34, 53, 46, 42, 50, 36, 29, 32
};

const int shiftBits[] = { 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };

const int E[] = {
    32, 1, 2, 3, 4, 5, 4, 5,
    6, 7, 8, 9, 8, 9, 10, 11,
    12, 13, 12, 13, 14, 15, 16, 17,
    16, 17, 18, 19, 20, 21, 20, 21,
    22, 23, 24, 25, 24, 25, 26, 27,
    28, 29, 28, 29, 30, 31, 32, 1
};

const int P[] = {
    16, 7, 20, 21, 29, 12, 28, 17,
    1, 15, 23, 26, 5, 18, 31, 10,
    2, 8, 24, 14, 32, 27, 3, 9,
    19, 13, 30, 6, 22, 11, 4, 25
};

const int S_BOX[8][4][16] = {
    {
        {14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7},
        {0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8},
        {4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0},
        {15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13}
    },
    {
        {15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10},
        {3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10,6, 9, 11, 5},
        {0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15},
        {13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9}
    },
    {
        {10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8},
        {13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1},
        {13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7},
        {1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12}
    },
    {
        {7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15},
        {13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9},
        {10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4},
        {3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14}
    },
    {
        {2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9},
        {14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6},
        {4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14},
        {11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3}
    },
    {
        {12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11},
        {10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8},
        {9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6},
        {4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13}
    },
    {
        {4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1},
        {13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6},
        {1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2},
        {6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12}
    },
    {
        {13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7},
        {1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2},
        {7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8},
        {2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11}
    }
};

// �����������ֽ�ת����
void byteToBit(const unsigned char* byte, bool* bit, int len) {
    for (int i = 0; i < len; ++i) {
        for (int j = 0; j < 8; ++j) {
            bit[i * 8 + 7 - j] = (byte[i] >> j) & 1;
        }
    }
}

// ��������������ת�ֽ�
void bitToByte(const bool* bit, unsigned char* byte, int len) {
    memset(byte, 0, len / 8);
    for (int i = 0; i < len; ++i) {
        if (bit[i]) {
            byte[i / 8] |= (1 << (7 - (i % 8)));
        }
    }
}

// ����������������
void xorBlock(const unsigned char* a, const unsigned char* b, unsigned char* out, int len) {
    for (int i = 0; i < len; ++i) {
        out[i] = a[i] ^ b[i];
    }
}

// DES��
class DES {
private:
    bool subKeys[16][48];

    void generateSubKeys(const unsigned char key[8]) {
        bool kBit[64];
        byteToBit(key, kBit, 8);

        bool pc1[56];
        for (int i = 0; i < 56; ++i) {
            pc1[i] = kBit[PC1[i] - 1];
        }

        bool C[28], D[28];
        memcpy(C, pc1, 28);
        memcpy(D, pc1 + 28, 28);

        for (int round = 0; round < 16; ++round) {
            leftShift(C, 28, shiftBits[round]);
            leftShift(D, 28, shiftBits[round]);

            bool CD[56];
            memcpy(CD, C, 28);
            memcpy(CD + 28, D, 28);

            for (int i = 0; i < 48; ++i)            {
                subKeys[round][i] = CD[PC2[i] - 1];
            }
        }
    }

    static void leftShift(bool* bits, int len, int shift) {
        bool temp[28];
        memcpy(temp, bits, shift * sizeof(bool));
        memcpy(bits, bits + shift, (len - shift) * sizeof(bool));
        memcpy(bits + len - shift, temp, shift * sizeof(bool));
    }

    void processBlock(const unsigned char* input, unsigned char* output, bool isEncrypt) {
        bool inputBits[64];
        byteToBit(input, inputBits, 8);

        bool processedBits[64];
        for (int i = 0; i < 64; ++i) {
            processedBits[i] = inputBits[IP[i] - 1];
        }

        bool L[32], R[32];
        memcpy(L, processedBits, 32 * sizeof(bool));
        memcpy(R, processedBits + 32, 32 * sizeof(bool));

        for (int round = 0; round < 16; ++round) {
            bool newL[32];
            memcpy(newL, R, 32 * sizeof(bool));

            bool fResult[32];
            feistel(R, subKeys[isEncrypt ? round : 15 - round], fResult);

            for (int i = 0; i < 32; ++i) {
                R[i] = L[i] ^ fResult[i];
            }

            memcpy(L, newL, 32 * sizeof(bool));
        }

        bool combined[64];
        memcpy(combined, R, 32 * sizeof(bool));
        memcpy(combined + 32, L, 32 * sizeof(bool));

        bool outputBits[64];
        for (int i = 0; i < 64; ++i) {
            outputBits[i] = combined[IP_INV[i] - 1];
        }

        bitToByte(outputBits, output, 64);
    }

    void feistel(const bool* R, const bool* subKey, bool* output) {
        bool expanded[48];
        for (int i = 0; i < 48; ++i) {
            expanded[i] = R[E[i] - 1];
        }

        for (int i = 0; i < 48; ++i) {
            expanded[i] ^= subKey[i];
        }

        bool sOut[32];
        for (int i = 0; i < 8; ++i) {
            int row = (expanded[i * 6] << 1) + expanded[i * 6 + 5];
            int col = (expanded[i * 6 + 1] << 3) | (expanded[i * 6 + 2] << 2) | (expanded[i * 6 + 3] << 1) | expanded[i * 6 + 4];
            int val = S_BOX[i][row][col];
            for (int j = 0; j < 4; ++j) {
                sOut[i * 4 + 3 - j] = (val >> j) & 1;
            }
        }

        for (int i = 0; i < 32; ++i) {
            output[i] = sOut[P[i] - 1];
        }
    }

public:
    DES(const unsigned char key[8]) {
        generateSubKeys(key);
    }

    void encryptBlock(const unsigned char* input, unsigned char* output) {
        processBlock(input, output, true);
    }

    void decryptBlock(const unsigned char* input, unsigned char* output) {
        processBlock(input, output, false);
    }
};

// ECBģʽ���ܺͽ���
void encryptECB(DES& des, const unsigned char* input, unsigned char* output, int len) {
    for (int i = 0; i < len; i += 8) {
        des.encryptBlock(input + i, output + i);
    }
}

void decryptECB(DES& des, const unsigned char* input, unsigned char* output, int len) {
    for (int i = 0; i < len; i += 8) {
        des.decryptBlock(input + i, output + i);
    }
}

// CBCģʽ���ܺͽ���
void encryptCBC(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    unsigned char prev[8];
    memcpy(prev, iv, 8);
    for (int i = 0; i < len; i += 8) {
        unsigned char block[8];
        xorBlock(prev, input + i, block, 8);
        des.encryptBlock(block, output + i);
        memcpy(prev, output + i, 8);
    }
}

void decryptCBC(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    unsigned char prev[8];
    memcpy(prev, iv, 8);
    for (int i = 0; i < len; i += 8) {
        unsigned char decrypted[8];
        des.decryptBlock(input + i, decrypted);
        xorBlock(prev, decrypted, output + i, 8);
        memcpy(prev, input + i, 8);
    }
}

// CFBģʽ���ܺͽ���
void encryptCFB8(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    unsigned char shiftReg[8];
    memcpy(shiftReg, iv, 8);
    for (int i = 0; i < len; ++i) {
        unsigned char encrypted[8];
        des.encryptBlock(shiftReg, encrypted);
        output[i] = input[i] ^ encrypted[0];
        memmove(shiftReg, shiftReg + 1, 7);
        shiftReg[7] = output[i];
    }
}

void decryptCFB8(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    encryptCFB8(des, iv, input, output, len);
}

// OFBģʽ���ܺͽ���
void encryptOFB8(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    unsigned char shiftReg[8];
    memcpy(shiftReg, iv, 8);
    for (int i = 0; i < len; ++i) {
        unsigned char encrypted[8];
        des.encryptBlock(shiftReg, encrypted);
        output[i] = input[i] ^ encrypted[0];
        memmove(shiftReg, shiftReg + 1, 7);
        shiftReg[7] = encrypted[0];
    }
}

void decryptOFB8(DES& des, const unsigned char* iv, const unsigned char* input, unsigned char* output, int len) {
    encryptOFB8(des, iv, input, output, len);
}

// ������������ȡʮ�������ַ����ļ�
string readHexString(const string& filename) {
    ifstream file(filename);
    string hexStr;
    getline(file, hexStr);
    file.close();
    return hexStr;
}

// ����������д��ʮ�������ַ����ļ�
void writeHexString(const string& filename, const string& hexStr) {
    ofstream file(filename);
    file << hexStr;
    file.close();
}

// ����������ʮ�������ַ���ת�ֽ�����
unique_ptr<unsigned char[]> hexToBytes(const string& hexStr, int& outLen) {
    outLen = hexStr.length() / 2;
    unique_ptr<unsigned char[]> bytes(new unsigned char[outLen]);
    for (int i = 0; i < outLen; ++i) {
        string byteStr = hexStr.substr(i * 2, 2);
        bytes[i] = stoul(byteStr, nullptr, 16);
    }
    return bytes;
}

// �����������ֽ�����תʮ�������ַ���
string bytesToHex(const unsigned char* bytes, int len) {
    stringstream ss;
    for (int i = 0; i < len; ++i) {
        ss << hex << uppercase << setw(2) << setfill('0') << (int)bytes[i];
    }
    return ss.str();
}

// ���ܲ���
void speedTest(DES& des, const string& mode, const unsigned char* iv) {
    const int dataSize = 5 * 1024 * 1024; // 5MB
    unique_ptr<unsigned char[]> data(new unsigned char[dataSize]);
    memset(data.get(), 0xAA, dataSize);

    unique_ptr<unsigned char[]> cipher(new unsigned char[dataSize]);
    unique_ptr<unsigned char[]> decrypted(new unsigned char[dataSize]);

    auto start = chrono::high_resolution_clock::now();
    for (int i = 0; i < 20; ++i) {
        if (mode == "ECB") {
            encryptECB(des, data.get(), cipher.get(), dataSize);
            decryptECB(des, cipher.get(), decrypted.get(), dataSize);
        }
        else if (mode == "CBC") {
            encryptCBC(des, iv, data.get(), cipher.get(), dataSize);
            decryptCBC(des, iv, cipher.get(), decrypted.get(), dataSize);
        }
        else if (mode == "CFB") {
            encryptCFB8(des, iv, data.get(), cipher.get(), dataSize);
            decryptCFB8(des, iv, cipher.get(), decrypted.get(), dataSize);
        }
        else if (mode == "OFB") {
            encryptOFB8(des, iv, data.get(), cipher.get(), dataSize);
            decryptOFB8(des, iv, cipher.get(), decrypted.get(), dataSize);
        }
    }
    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end - start).count();

    double totalData = 20.0 * dataSize * 2 / (1024.0 * 1024); // �������� (MB)
    double speed = totalData / (duration / 1000.0); // �ٶ� (MB/s)

    cout << "ģʽ: " << mode << " ��ʱ: " << duration << "ms �ٶ�: " << speed << " MB/s" << endl;
}

int main(int argc, char* argv[]) {
    string plainFile, keyFile, viFile, mode, cipherFile;
    bool hasIV = false;

    // ���������в���
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-p") == 0) plainFile = argv[++i];
        else if (strcmp(argv[i], "-k") == 0) keyFile = argv[++i];
        else if (strcmp(argv[i], "-v") == 0) { viFile = argv[++i]; hasIV = true; }
        else if (strcmp(argv[i], "-m") == 0) mode = argv[++i];
        else if (strcmp(argv[i], "-c") == 0) cipherFile = argv[++i];
    }

    // ����Ҫ�����Ƿ�����
    if (plainFile.empty() || keyFile.empty() || mode.empty() || cipherFile.empty()) {
        cerr << "����������ȷ���ṩ�����ļ�����Կ�ļ���ģʽ�������ļ���" << endl;
        return 1;
    }

    // �����ҪIV��ģʽ�Ƿ��ṩ��IV
    if ((mode == "CBC" || mode == "CFB" || mode == "OFB") && !hasIV) {
        cerr << "ģʽ " << mode << " ��Ҫ�ṩ��ʼ������ (IV) �ļ���" << endl;
        return 1;
    }

    // ��ȡ��Կ
    string keyHex = readHexString(keyFile);
    int keyLen;
    unique_ptr<unsigned char[]> key = hexToBytes(keyHex, keyLen);
    if (keyLen != 8) {
        cerr << "��Կ���ȱ���Ϊ64λ (8�ֽ�)��" << endl;
        return 1;
    }
    DES des(key.get());

    // ��ȡ����
    string plainHex = readHexString(plainFile);
    int plainLen;
    unique_ptr<unsigned char[]> plain = hexToBytes(plainHex, plainLen);

    // ��ȡIV�������Ҫ��
    unsigned char iv[8] = {0};
    if (hasIV) {
        string viHex = readHexString(viFile);
        int viLen;
        unique_ptr<unsigned char[]> viBytes = hexToBytes(viHex, viLen);
        if (viLen != 8) {
            cerr << "��ʼ������ (IV) �ĳ��ȱ���Ϊ64λ (8�ֽ�)��" << endl;
            return 1;
        }
        memcpy(iv, viBytes.get(), 8);
    }

    // ����
    unique_ptr<unsigned char[]> cipher(new unsigned char[plainLen]);
    if (mode == "ECB") encryptECB(des, plain.get(), cipher.get(), plainLen);
    else if (mode == "CBC") encryptCBC(des, iv, plain.get(), cipher.get(), plainLen);
    else if (mode == "CFB") encryptCFB8(des, iv, plain.get(), cipher.get(), plainLen);
    else if (mode == "OFB") encryptOFB8(des, iv, plain.get(), cipher.get(), plainLen);
    else {
        cerr << "��֧�ֵļ���ģʽ��" << endl;
        return 1;
    }

    // д������
    writeHexString(cipherFile, bytesToHex(cipher.get(), plainLen));

    // ���ܲ���
    if (hasIV) speedTest(des, mode, iv);
    else speedTest(des, mode, nullptr);

    return 0;
}
